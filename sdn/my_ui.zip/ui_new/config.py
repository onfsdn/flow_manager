server="localhost";
port = "5984"
username="admin";
password="admin";
database="sdnhackfest";
user="user"
rest_url = "http://172.16.0.6:5984/"